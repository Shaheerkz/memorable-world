<footer class="foot-sec">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="main-wrapper">
                    <div class="footer-content">
                        <p>© 2000-2023, All Rights Reserved</p>
                    </div>
                    <div class="icon-wrap d-flex">
                        <div class="icon-1">
                            <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                        </div>
                        <div class="icon-1">
                            <a href="#"><i class="fa-brands fa-youtube"></i></a>
                        </div>
                        <div class="icon-1">
                            <a href="#"><i class="fa-solid fa-basketball"></i></a>
                        </div>
                        <div class="icon-1">
                            <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>